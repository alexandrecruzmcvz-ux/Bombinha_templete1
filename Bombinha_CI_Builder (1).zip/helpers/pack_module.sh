#!/system/bin/sh
# Uso: sh pack_module.sh /sdcard/Download/Bombinha.apk /sdcard/Download/Bombinha_Magisk_Module_FULL.zip /sdcard/Download/Bombinha_READY.zip
APK="$1"; MODULE="$2"; OUT="$3"
if [ ! -f "$APK" ] || [ ! -f "$MODULE" ] || [ -z "$OUT" ]; then
  echo "Uso: sh pack_module.sh /caminho/Bombinha.apk /caminho/Modulo.zip /caminho/saida.zip"
  exit 1
fi
TMP="/sdcard/bombinha_tmp_$$"
mkdir -p "$TMP" && cd "$TMP" || exit 1
unzip -q "$MODULE" -d "$TMP" || exit 1
cp -f "$APK" "$TMP/common/Bombinha.apk"
cd "$TMP"
zip -r "$OUT" . > /dev/null
echo "Pronto: $OUT"
rm -rf "$TMP"
