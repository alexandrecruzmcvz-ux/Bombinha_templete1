Bombinha CI Builder (para celular)

1) Crie um repositório no GitHub e suba o conteúdo do Bombinha_v2 (a pasta inteira).
2) Adicione esta pasta `.github/workflows/android.yml` na raiz do repositório.
3) Vá em GitHub > Actions > Build Bombinha APK > Run workflow.
4) Ao finalizar, baixe o artefato `Bombinha-APK` (contém `app-debug.apk`).

Depois use o módulo Magisk FULL para embutir o APK e instalar.
